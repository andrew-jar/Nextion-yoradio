#ifndef myoptions_h
#define myoptions_h


#define L10N_LANGUAGE       RU

#define NEXTION_RX			16  //TX Nextion → GPIO16 (RX) na ESP32-S3
#define NEXTION_TX			17  //RX Nextion → GPIO17 (TX) na ESP32-S3

#define I2S_DOUT			  9
#define I2S_BCLK			  3
#define I2S_LRC			    1

#define IR_PIN			    4

#endif
